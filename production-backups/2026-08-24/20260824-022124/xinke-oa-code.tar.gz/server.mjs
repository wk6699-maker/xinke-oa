import { createServer } from 'node:http';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import mysql from 'mysql2/promise';
import nodemailer from 'nodemailer';

function loadDotEnv() {
  const envPath = resolve(process.cwd(), '.env');
  if (!existsSync(envPath)) return;
  for (const line of readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!match || match[1].startsWith('#') || process.env[match[1]] !== undefined) continue;
    process.env[match[1]] = match[2].replace(/^(['"])(.*)\1$/, '$2');
  }
}

loadDotEnv();
const port = Number(process.env.API_PORT || 8787);
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)));
const distDir = resolve(projectRoot, 'dist');
const databaseUrl = process.env.DATABASE_URL || process.env.MYSQL_URL;
const databaseName = process.env.MYSQL_DATABASE || 'xinke_oa';

function getDatabaseConfig() {
  if (databaseUrl) {
    const url = new URL(databaseUrl);
    return {
      host: url.hostname || '127.0.0.1',
      port: Number(url.port || 3306),
      user: decodeURIComponent(url.username || 'root'),
      password: decodeURIComponent(url.password || ''),
      database: decodeURIComponent(url.pathname.replace(/^\//, '')) || databaseName,
    };
  }
  return {
    host: process.env.MYSQL_HOST || '127.0.0.1',
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || 'root',
    password: process.env.MYSQL_PASSWORD || '',
    database: databaseName,
  };
}

const dbConfig = getDatabaseConfig();
const smtpConfig = {
  host: process.env.SMTP_HOST || '',
  port: Number(process.env.SMTP_PORT || 465),
  secure: String(process.env.SMTP_SECURE || 'true').toLowerCase() !== 'false',
  user: process.env.SMTP_USER || '',
  password: process.env.SMTP_PASSWORD || '',
  from: process.env.SMTP_FROM || process.env.SMTP_USER || '',
};
const pool = mysql.createPool({
  ...dbConfig,
  waitForConnections: true,
  connectionLimit: Number(process.env.MYSQL_CONNECTION_LIMIT || 10),
  queueLimit: 0,
  charset: 'utf8mb4',
  dateStrings: true,
});
let smtpTransport;
let schedulerTimer;
const emailTestAttempts = new Map();

function getSmtpTransport() {
  if (!smtpConfig.host || !smtpConfig.user || !smtpConfig.password || !smtpConfig.from) throw new Error('SMTP_NOT_CONFIGURED');
  if (!smtpTransport) {
    smtpTransport = nodemailer.createTransport({
      host: smtpConfig.host,
      port: smtpConfig.port,
      secure: smtpConfig.secure,
      auth: smtpConfig.user ? { user: smtpConfig.user, pass: smtpConfig.password } : undefined,
      tls: { rejectUnauthorized: String(process.env.SMTP_TLS_REJECT_UNAUTHORIZED || 'true').toLowerCase() !== 'false' },
    });
  }
  return smtpTransport;
}

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function normalizeRecipients(value) {
  const recipients = [...new Set((Array.isArray(value) ? value : String(value || '').split(/[;,\s]+/)).map(item => String(item).trim().toLowerCase()).filter(Boolean))];
  if (!recipients.length || recipients.length > 100 || recipients.some(item => !emailPattern.test(item))) throw new Error('INVALID_RECIPIENTS');
  return recipients;
}

function money(value) {
  return `¥${Number(value || 0).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function reminderRecords(payload, now = new Date()) {
  const records = Array.isArray(payload?.records) ? payload.records : [];
  const payments = Array.isArray(payload?.payments) ? payload.payments : [];
  const clients = Array.isArray(payload?.clients) ? payload.clients : [];
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const limit = new Date(today);
  limit.setDate(limit.getDate() + 10);
  return records.filter(record => {
    const paid = Number(record.paid || 0) + payments.filter(payment => payment.docId === record.docId).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
    if (Number(record.fee || 0) <= paid || !record.paymentDate) return false;
    const due = new Date(`${record.paymentDate}T00:00:00`);
    return !Number.isNaN(due.getTime()) && due <= limit;
  }).map(record => {
    const paid = Number(record.paid || 0) + payments.filter(payment => payment.docId === record.docId).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
    const client = clients.find(item => item.id === record.clientId);
    return `${client?.company || '未知客户'} | 单据ID ${record.docId || record.id} | 预计支付 ${record.paymentDate || '待定'} | 未付款 ${money(Number(record.fee || 0) - paid)}`;
  });
}

function scheduleBucket(frequency, date) {
  if (frequency === 'monthly') return `${date.getFullYear()}-${date.getMonth() + 1}`;
  if (frequency === 'weekly') {
    const monday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const day = monday.getDay() || 7;
    monday.setDate(monday.getDate() - day + 1);
    return `${monday.getFullYear()}-${monday.getMonth() + 1}-${monday.getDate()}`;
  }
  return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
}

function isScheduleDue(schedule, now) {
  if (!schedule?.enabled || !Array.isArray(schedule.recipients) || !schedule.recipients.length) return false;
  const [hour, minute] = String(schedule.sendTime || '09:00').split(':').map(Number);
  if (!Number.isFinite(hour) || !Number.isFinite(minute) || now.getHours() * 60 + now.getMinutes() < hour * 60 + minute) return false;
  if (schedule.frequency === 'weekly') {
    const selectedDay = Math.min(7, Math.max(1, Number(schedule.weekDay || 1)));
    const currentDay = now.getDay() || 7;
    if (currentDay !== selectedDay) return false;
  }
  if (schedule.frequency === 'monthly') {
    const selectedDay = Math.min(31, Math.max(1, Number(schedule.monthDay || 1)));
    const lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    if (now.getDate() !== Math.min(selectedDay, lastDayOfMonth)) return false;
  }
  const currentBucket = scheduleBucket(schedule.frequency, now);
  return !schedule.lastAutoSentAt || scheduleBucket(schedule.frequency, new Date(schedule.lastAutoSentAt)) !== currentBucket;
}

async function sendReminderEmail(payload, recipients, now, reason = 'scheduled') {
  const lines = reminderRecords(payload, now);
  const body = `昕科OA系统收款提醒\n\n${lines.length ? lines.join('\n') : '当前没有预计支付时间在10天内或已过期的未付款记录。'}\n\n此邮件由昕科OA系统自动生成。`;
  const subject = `收款提醒 · ${now.toLocaleDateString('zh-CN')}`;
  await getSmtpTransport().sendMail({ from: smtpConfig.from, to: recipients.join(', '), subject, text: body, headers: { 'X-Xinke-OA-Email': reason } });
  return { subject, count: lines.length };
}

async function initDatabase() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS app_state (
      id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
      version BIGINT UNSIGNED NOT NULL,
      payload LONGTEXT NOT NULL,
      updated_at DATETIME(3) NOT NULL,
      CONSTRAINT app_state_singleton CHECK (id = 1)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);
}

async function readState(connection = pool, forUpdate = false) {
  const [rows] = await connection.query(`SELECT version, payload, updated_at FROM app_state WHERE id = 1${forUpdate ? ' FOR UPDATE' : ''}`);
  const row = rows[0];
  if (!row) return { version: 0, payload: null, updatedAt: null };
  return { version: Number(row.version), payload: JSON.parse(row.payload), updatedAt: row.updated_at };
}

async function writeState(expectedVersion, payload) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const current = await readState(connection, true);
    if (current.version !== expectedVersion) {
      await connection.rollback();
      return null;
    }
    const nextVersion = current.version + 1;
    const updatedAt = new Date();
    if (current.payload === null) {
      await connection.query('INSERT INTO app_state (id, version, payload, updated_at) VALUES (1, ?, ?, ?)', [nextVersion, JSON.stringify(payload), updatedAt]);
    } else {
      await connection.query('UPDATE app_state SET version = ?, payload = ?, updated_at = ? WHERE id = 1', [nextVersion, JSON.stringify(payload), updatedAt]);
    }
    await connection.commit();
    return { version: nextVersion, payload, updatedAt: updatedAt.toISOString() };
  } catch (error) {
    await connection.rollback().catch(() => {});
    throw error;
  } finally {
    connection.release();
  }
}

const send = (res, status, body) => {
  const json = JSON.stringify(body);
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'access-control-allow-origin': '*' });
  res.end(json);
};

const contentTypes = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
};

function requestPath(req) {
  try {
    return new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`).pathname;
  } catch {
    return '/';
  }
}

function serveStatic(req, res) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    send(res, 405, { error: 'Method not allowed' });
    return;
  }
  const pathname = requestPath(req);
  let relativePath;
  try {
    relativePath = decodeURIComponent(pathname === '/' ? '/index.html' : pathname);
  } catch {
    send(res, 400, { error: 'Invalid URL' });
    return;
  }
  let filePath = resolve(distDir, `.${relativePath}`);
  const isInsideDist = filePath === distDir || filePath.startsWith(`${distDir}${sep}`);
  if (!isInsideDist || !existsSync(filePath)) filePath = resolve(distDir, 'index.html');
  try {
    const body = readFileSync(filePath);
    res.writeHead(200, { 'content-type': contentTypes[extname(filePath).toLowerCase()] || 'application/octet-stream', 'cache-control': extname(filePath) === '.html' ? 'no-cache' : 'public, max-age=31536000, immutable' });
    if (req.method === 'HEAD') res.end();
    else res.end(body);
  } catch {
    send(res, 404, { error: 'Not found' });
  }
}

function readJsonBody(req, maxBytes = 1024 * 1024) {
  return new Promise((resolveBody, reject) => {
    let raw = '';
    req.setEncoding('utf8');
    req.on('data', chunk => {
      raw += chunk;
      if (Buffer.byteLength(raw) > maxBytes) reject(new Error('PAYLOAD_TOO_LARGE'));
    });
    req.on('end', () => {
      try { resolveBody(JSON.parse(raw || '{}')); } catch { reject(new Error('INVALID_JSON')); }
    });
    req.on('error', reject);
  });
}

async function runScheduledEmail() {
  try {
    const state = await readState();
    if (!state.payload || !isScheduleDue(state.payload.emailSchedule, new Date())) return;
    const schedule = state.payload.emailSchedule;
    const now = new Date();
    const recipients = normalizeRecipients(schedule.recipients);
    await sendReminderEmail(state.payload, recipients, now, 'scheduled');
    const nextPayload = {
      ...state.payload,
      emailSchedule: { ...schedule, recipients, lastAutoSentAt: now.toISOString(), lastSentAt: now.toISOString(), lastError: undefined },
    };
    if (!(await writeState(state.version, nextPayload))) console.warn('Scheduled email sent, but state version changed before last-send timestamp could be saved.');
    else console.log(`Scheduled reminder email sent to ${recipients.length} recipient(s).`);
  } catch (error) {
    if (error?.message === 'SMTP_NOT_CONFIGURED') return;
    console.error('Scheduled reminder email failed:', error?.message || error);
  }
}

const server = createServer((req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET, PUT, OPTIONS', 'access-control-allow-headers': 'content-type, if-match' });
    res.end();
    return;
  }
  const pathname = requestPath(req);
  if (pathname === '/api/email/status' && req.method === 'GET') {
    send(res, 200, { configured: Boolean(smtpConfig.host && smtpConfig.user && smtpConfig.password && smtpConfig.from), provider: smtpConfig.host === 'smtp.qiye.aliyun.com' ? 'aliyun-enterprise' : 'custom', from: smtpConfig.from || null });
    return;
  }
  if (pathname === '/api/email/test' && req.method === 'POST') {
    const clientAddress = req.socket.remoteAddress || 'unknown';
    const nowMs = Date.now();
    const recentAttempts = (emailTestAttempts.get(clientAddress) || []).filter(timestamp => nowMs - timestamp < 10 * 60 * 1000);
    if (recentAttempts.length >= 5) {
      send(res, 429, { error: '测试发送次数过多，请10分钟后再试' });
      return;
    }
    recentAttempts.push(nowMs);
    emailTestAttempts.set(clientAddress, recentAttempts);
    readJsonBody(req).then(async body => {
      try {
        const state = await readState();
        const recipients = normalizeRecipients(body.recipients);
        const result = await sendReminderEmail(state.payload || {}, recipients, new Date(), 'test');
        if (state.payload) {
          const nextPayload = { ...state.payload, emailSchedule: { ...state.payload.emailSchedule, recipients, lastTestAt: new Date().toISOString(), lastError: undefined } };
          await writeState(state.version, nextPayload);
        }
        send(res, 200, { sent: true, recipients, ...result });
      } catch (error) {
        const code = error?.message;
        const status = code === 'SMTP_NOT_CONFIGURED' ? 503 : code === 'INVALID_RECIPIENTS' ? 400 : 502;
        const messages = { SMTP_NOT_CONFIGURED: 'SMTP尚未配置，请联系管理员补充企业邮箱SMTP信息', INVALID_RECIPIENTS: '收件邮箱格式不正确' };
        send(res, status, { error: messages[code] || '邮件发送失败' });
      }
    }).catch(error => send(res, error?.message === 'PAYLOAD_TOO_LARGE' ? 413 : 400, { error: error?.message === 'PAYLOAD_TOO_LARGE' ? 'Request too large' : 'Invalid JSON' }));
    return;
  }
  if (pathname === '/api/state' && req.method === 'GET') {
    readState().then(state => send(res, 200, state)).catch(error => {
      console.error('MySQL read failed:', error.message);
      send(res, 503, { error: 'Database unavailable' });
    });
    return;
  }
  if (pathname === '/api/state' && req.method !== 'PUT') {
    send(res, 405, { error: 'Method not allowed' });
    return;
  }
  if (pathname !== '/api/state') {
    serveStatic(req, res);
    return;
  }
  readJsonBody(req).then(body => {
    (async () => {
      try {
        const expectedVersion = Number(req.headers['if-match']);
        if (!Number.isInteger(expectedVersion) || !body.payload || typeof body.payload !== 'object') {
          send(res, 400, { error: 'Invalid state payload' });
          return;
        }
        const saved = await writeState(expectedVersion, body.payload);
        if (!saved) {
          send(res, 409, { error: 'State conflict', ...(await readState()) });
          return;
        }
        send(res, 200, saved);
      } catch (error) {
        console.error('MySQL write failed:', error.message);
        const databaseError = typeof error?.code === 'string' && error.code.startsWith('ER_');
        send(res, databaseError ? 503 : 400, { error: databaseError ? 'Database unavailable' : 'Invalid JSON' });
      }
    })();
  }).catch(error => send(res, error?.message === 'PAYLOAD_TOO_LARGE' ? 413 : 400, { error: error?.message === 'PAYLOAD_TOO_LARGE' ? 'Request too large' : 'Invalid JSON' }));
});

async function shutdown(signal) {
  console.log(`${signal} received, closing MySQL pool`);
  if (schedulerTimer) clearInterval(schedulerTimer);
  server.close(() => pool.end().finally(() => process.exit(0)));
}

process.on('SIGINT', () => { void shutdown('SIGINT'); });
process.on('SIGTERM', () => { void shutdown('SIGTERM'); });

initDatabase().then(() => {
  server.listen(port, '0.0.0.0', () => {
    console.log(`Xinke state API listening on http://127.0.0.1:${port} (MySQL ${dbConfig.host}:${dbConfig.port}/${dbConfig.database})`);
    void runScheduledEmail();
    schedulerTimer = setInterval(() => { void runScheduledEmail(); }, 60000);
  });
}).catch(error => {
  console.error(`Unable to initialize MySQL database ${dbConfig.database} at ${dbConfig.host}:${dbConfig.port}:`, error.message);
  console.error('Set MYSQL_HOST, MYSQL_PORT, MYSQL_USER, MYSQL_PASSWORD and MYSQL_DATABASE, or DATABASE_URL.');
  void pool.end().finally(() => process.exit(1));
});
